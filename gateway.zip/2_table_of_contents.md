## Agenda

Was ist Spring Cloud Gateway? <!-- .element: class="fragment" -->

Wie funktioniert Spring Cloud Gateway? <!-- .element: class="fragment" -->

Was beinhaltet Spring Cloud Gateway? <!-- .element: class="fragment" -->


